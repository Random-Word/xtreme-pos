package com.example.eposeasyselectsample.printer;

// ------------------------------------------------------------------------------------------------
public interface PrintCallback
{
	// --------------------------------------------------------------------------------------------
	/**
	 *	print result callback
	 *
	 *	@param	result
	 *
	 */
	public void onPrintCallback(
			boolean	result );
}
